<template>
  <div class="dashboard-container">设备管理</div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {}
}
</script>

<style scoped></style>
