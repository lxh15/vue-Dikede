<template>
  <div>
    <el-button type="primary" icon="el-icon-circle-plus-outline"
      >新建</el-button
    >
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style scoped>
.el-button--primary {
  width: 80px !important;
  height: 36px;
  padding: 0;
  background: linear-gradient(135deg, #ff9743, #ff5e20) !important;
  border: none;
}
</style>
